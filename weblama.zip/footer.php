<div id="footer">
    <marquee><p>&copy; Ripr Lutuk 2018 </p>
    </marquee>
</div>
</body>
</html>
