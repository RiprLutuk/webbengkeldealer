<?php
	session_start();
	include "header.php";
	$sesi 	= $_SESSION['admin'];
	if(!isset($sesi)) {
		header("location: index.php");
	}
?>

	<div class="clear"></div>
	<div class="container">
		<div class="content" align="right">
		<?php
				echo "<b>Hai..!!!,  ".$sesi."</b><br/>";
			?>
			<div class="title"></div>
			<div class="box" align="center">
			<div class="card card-login ">
			<b><div class="card-header">SELAMAT DATANG</div></b>
                  <div class="card-body">
				<p align="center">Di Halaman Administrator Bengkel Dealer Pemalang<br/><br/>
					<button class="btn btn-primary" name="ubah-password" onclick="window.location.href='ubahpassword.php'">Ubah Password</button>
				</p>
			</div>
			</div>
		</div>
		</div>
		</div>
	<br />
	</div>
	<div class="clear"></div>
<?php
	include "footer.php";
?>
