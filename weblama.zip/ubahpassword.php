<?php
session_start();
include "./header.php";
$sesi = $_SESSION['admin'];
if (!isset($sesi)) {
    header("location: index.php");
}
?>

<div class="clear"></div>
<div class="container"  align="center">
    <br />
    <div class="content">
        <div class="card card-login mx-auto mt-5">
            <b><div class="card-header">Ubah Password Administrator</div></b>
            <div class="card-body" align="left">
                <?php
                if (isset($_POST['oldPass'])) {
                    $newPass = $_POST['newPass'];
                    $oldPass = $_POST['oldPass'];

                    $stmt = $db->prepare('update user set password=MD5(:newPass) where username=:username AND password=MD5(:oldPass)');
                    $stmt->bindValue(":newPass", $newPass, PDO::PARAM_STR);
                    $stmt->bindValue(":oldPass", $oldPass, PDO::PARAM_STR);
                    $stmt->bindValue(":username", $sesi, PDO::PARAM_STR);
                    $stmt->execute();
                    if ($stmt->rowCount() > 0) {
                        echo '<script language="JavaScript">alert("Password Telah Diubah");window.location = "beranda.php";</script>';
                    } else {
                        echo '<script language="JavaScript">alert("Gagal Mengubah Password");</script>';
                    }
                }
                ?>

                <!-- Form Input -->
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="oldPass">Password Lama</label>
                        <input type="password" class="form-control" name="oldPass" id="oldPass" placeholder="Masukkan Password Lama"  oninvalid="setCustomValidity('Isi Password Lama Terlebih Dahulu')" onchange="try {
                                    setCustomValidity('')
                                } catch (e) {
                                }" required>
                    </div>
                    <div class="form-group">
                        <label for="newPass">Password Baru</label>
                        <input type="password" name="newPass" id="newPass" class="form-control" placeholder="Masukkan Password Baru" oninvalid="setCustomValidity('Isi Password Terlebih Dahulu')" onchange="try {
                                    setCustomValidity('')
                                } catch (e) {
                                }" required>
                    </div>
                    <div class="form-group">
                    </div>
                    <button type="submit" class="btn btn-primary btn-group" name="ubah">Ubah</button>
                    <button type="button" class="btn btn-warning btn-group" onclick="window.location.href = 'beranda.php'">Batal</button>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>
<br />
<div class="clear"></div>
<?php
include "footer.php";
?>
