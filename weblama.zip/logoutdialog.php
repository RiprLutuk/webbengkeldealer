<?php
	session_start();
	include "header.php";
	$sesi 	= $_SESSION['admin'];
	if(!isset($sesi)) {
		header("location: index.php");
	}
?>

	<div class="clear"></div>
	<div class="container">
	<br />
		<div class="content">
			<div class="box" align="center">
			<div class="card card-login">
				<b><div class="card-header">LOGOUT SISTEM</div></b>
				<p align="center">
					<b>Yakin akan keluar dari sistem ?</b>. <br /><br />
					<center>
					<button type="button" class="btn btn-primary" onclick="window.location.href='logout.php'">Ya</button>
					<span style="margin:10px">
						<button type="button" class="btn btn-primary" onclick="window.location.href='beranda.php'">Tidak</button>
					</span>
				</center>
				</p>
			</div>
			</div>
		</div>
		</div>
	<br />
	</div>
	<div class="clear"></div>
<?php
	include "footer.php";
?>
