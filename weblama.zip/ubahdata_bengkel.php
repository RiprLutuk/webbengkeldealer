<?php
session_start();
$sesi = $_SESSION['admin'];
if (!isset($sesi)) {
    header("location: index.php");
}

include "header.php";
$kdbengkel = $_GET['kdbengkel'];

$stmt = $db->prepare('select * from data_bengkel where kdbengkel=:kdbengkel');
$stmt->bindValue(":kdbengkel", $kdbengkel, PDO::PARAM_STR);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<div class="clear"></div>
<div class="container">
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading" align='center'>
                        UBAH DATA BENGKEL
                    </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <form class="form-horizontal" action="editbengkel.php" method="POST" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Kode Bengkel</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="kdbengkel" id="kdbengkel" value="<?php echo $row['kdbengkel']; ?>" required readonly/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Nama Bengkel</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="nmbengkel" id="nmbengkel" value="<?php echo $row['nmbengkel']; ?>" placeholder="Masukan Nama Bengkel" oninvalid="setCustomValidity('Isi Nama Bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Jumlah Bengkel</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" name="jmlmontir" id="jmlkaryawan" value="<?php echo $row['jmlmontir']; ?>" placeholder="Masukan Jumlah Montir, Isikan Angka 0 Jika Tidak Ada" oninvalid="setCustomValidity('Isi Jumlah Montir Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" onkeyup="validAngka(this)" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Hari Buka</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="haribuka" id="haribuka" value="<?php echo $row['haribuka']; ?>" placeholder="Masukan Haribuka Ex= (Senin - Minggu)" oninvalid="setCustomValidity('Isi Hari Buka Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Jam Buka</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="jambuka" id="jambuka" value="<?php echo $row['jambuka']; ?>" placeholder="Masukan Jam Buka Ex= (08.00 - 17.00)" oninvalid="setCustomValidity('Isi Jam Buka Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Alamat</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="alamat" id="alamat" value="<?php echo $row['alamat']; ?>" placeholder="Masukan Alamat bengkel" oninvalid="setCustomValidity('Isi Alamat bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Kelurahan</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="kelurahan" id="kelurahan" value="<?php echo $row['kelurahan']; ?>" placeholder="Masukan Kelurahan bengkel" oninvalid="setCustomValidity('Isi Kelurahan bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Kecamatan</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="kecamatan" name="kecamatan" oninvalid="setCustomValidity('Pilih Kecamatan bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                        <option value="">--Pilih Kecamatan bengkel--</option>
                                        <option value="Ampelgading" <?php echo $row['kecamatan'] == "Ampelgading" ? "selected" : ""; ?> >Ampelgading</option>
                                        <option value="Bantarbolang" <?php echo $row['kecamatan'] == "Bantarbolang" ? "selected" : ""; ?> >Bantarbolang</option>
                                        <option value="Belik" <?php echo $row['kecamatan'] == "Belik" ? "selected" : ""; ?> >Belik</option>
                                        <option value="Bodeh" <?php echo $row['kecamatan'] == "Bodeh" ? "selected" : ""; ?> >Bodeh</option>
                                        <option value="Comal" <?php echo $row['kecamatan'] == "Comal" ? "selected" : ""; ?> >Comal</option>
                                        <option value="Moga" <?php echo $row['kecamatan'] == "Moga" ? "selected" : ""; ?> >Moga</option>
                                        <option value="Pemalang" <?php echo $row['kecamatan'] == "Pemalang" ? "selected" : ""; ?> >Pemalang</option>
                                        <option value="Petarukan" <?php echo $row['kecamatan'] == "Petarukan" ? "selected" : ""; ?> >Petarukan</option>
                                        <option value="Pulosari" <?php echo $row['kecamatan'] == "Pulosari" ? "selected" : ""; ?> >Pulosari</option>
                                        <option value="Randudongkal" <?php echo $row['kecamatan'] == "Randudongkal" ? "selected" : ""; ?> >Randudongkal</option>
                                        <option value="Taman" <?php echo $row['kecamatan'] == "Taman" ? "selected" : ""; ?> >Taman</option>
                                        <option value="Ulujami" <?php echo $row['kecamatan'] == "Ulujami" ? "selected" : ""; ?> >Ulujami</option>
                                        <option value="Warungpring" <?php echo $row['kecamatan'] == "Warungpring" ? "selected" : ""; ?> >Warungpring</option>
                                        <option value="Watukumptul" <?php echo $row['kecamatan'] == "Watukumptul" ? "selected" : ""; ?> >Watukumptul</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Kode Pos</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="kdpos" id="kdpos" value="<?php echo $row['kdpos']; ?>" placeholder="Masukan Kode Pos bengkel" oninvalid="setCustomValidity('Isi Kode Pos bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" onkeyup="validAngka(this)" maxlength="5" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Kabupaten</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="kabupaten" name="kabupaten" oninvalid="setCustomValidity('Pilih Kabupaten bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" required/>
                                        <option value="">--Pilih Kabupaten bengkel--</option>
                                        <option value="Pemalang" <?php echo $row['kabupaten'] == "Pemalang" ? "selected" : ""; ?> >Pemalang</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">No. Telepon</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="telepon" id="telepon" value="<?php echo $row['telepon']; ?>" placeholder="Masukan No. Telepon bengkel, Isikan Angka 0 Jika Tidak Ada" oninvalid="setCustomValidity('Isi No. Telepon bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" onkeyup="validAngka(this)" maxlength="12" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Latitude</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="latitude" id="latitude" value="<?php echo $row['latitude']; ?>" placeholder="Masukan Latitude bengkel, Isikan Angka 0 Jika Tidak Ada" oninvalid="setCustomValidity('Isi Latitude bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" onkeyup="validLatLon(this)" maxlength="10" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Longitude</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="longitude" id="longitude" value="<?php echo $row['longitude']; ?>" placeholder="Masukan Longitude bengkel, Isikan Angka 0 Jika Tidak Ada" oninvalid="setCustomValidity('Isi Longitude bengkel Terlebih Dahulu')" onchange="try {
                                                    setCustomValidity('')
                                                } catch (e) {
                                                }" onkeyup="validLatLon(this)" maxlength="11" required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Foto</label>
                                    <div class="col-sm-8">
                                        <img src="img/<?php echo $row['foto'] ?>" width="100px" height="60px"/>
                                    </div>
                                </div>
                                <div align="center">
                                    <button type='submit' class='btn btn-primary' name='ubah'>Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "./footer.php";
?>

<script language='javascript'>
    function validAngka(a) {
        if (!/^[0-9]+$/.test(a.value)) {
            a.value = a.value.substring(0, a.value.length - 1);
        }
    }
    function validLatLon(a) {
        if (!/^[0-9.-]+$/.test(a.value)) {
            a.value = a.value.substring(0, a.value.length - 1);
        }
    }
</script>